import { BrowserRouter, Routes, Route } from "react-router-dom"
import Home from "./pages/Home"
import Courses from "./pages/Courses"
import BlogDetail from "./pages/BlogDetail"


export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/courses" element={<Courses />} />
        <Route path="/blog/:id" element={<BlogDetail />} />

      </Routes>
    </BrowserRouter>
  )
}
