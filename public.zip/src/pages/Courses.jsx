import Navbar from "../components/Navbar"
import CourseCard from "../components/CourseCard"

const courses = [
  { title: "CA Foundation", price: "₹999" },
  { title: "CS Executive", price: "₹1299" },
  { title: "CMA Intermediate", price: "₹1199" },
  { title: "Interview Preparation", price: "₹499" },
  { title: "AI CV Enhance", price: "₹199" },
  { title: "Study Abroad Guidance", price: "₹799" },
]

export default function Courses() {
  return (
    <>
      <Navbar />

      <div className="px-10 py-20">
        <h1 className="text-4xl font-bold text-center mb-12">
          All Courses
        </h1>

        <div className="grid md:grid-cols-3 gap-8">
          {courses.map((c, i) => (
            <CourseCard key={i} {...c} />
          ))}
        </div>
      </div>
    </>
  )
}
