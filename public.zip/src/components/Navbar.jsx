export default function Navbar() {
  return (
    <div className="absolute top-0 left-0 w-full z-20 text-white">
      <div className="flex justify-between items-center px-10 py-5">
        <h1 className="text-xl font-bold">EscapeNormie</h1>

        <div className="space-x-6 text-sm uppercase">
          <a href="/" className="hover:text-yellow-400">Home</a>
          <a href="/courses" className="hover:text-yellow-400">All Courses</a>
          <a href="#" className="hover:text-yellow-400">About</a>
          <a href="#" className="hover:text-yellow-400">Contact</a>
        </div>
      </div>
    </div>
  )
}
