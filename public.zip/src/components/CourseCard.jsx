export default function CourseCard({ title, price }) {
  return (
    <div className="bg-white p-6 rounded-xl shadow hover:shadow-xl transition hover:-translate-y-1">
      <h3 className="text-xl font-semibold mb-3">{title}</h3>
      <p className="text-blue-600 font-bold">{price}</p>
      <button className="mt-4 bg-blue-600 text-white px-4 py-2 rounded">
        View
      </button>
    </div>
  )
}
