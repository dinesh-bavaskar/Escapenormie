import { useEffect, useRef } from "react"

const blogs = [
  {
    title: "How to Successfully Prepare for Studying Abroad: From Application to Arrival",
    date: "November 16, 2025",
    img: "https://images.unsplash.com/photo-1522202176988-66273c2fd55f",
  },
  {
  title: "The Rise of Online Learning: How Virtual Education is Shaping the Future of Students",
  date: "December 2, 2025",
  img: "https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&w=1200&q=80",
},

  {
    title: "The Ultimate Guide to Choosing the Right Career Path After 12th Grade",
    date: "December 20, 2025",
    img: "https://images.unsplash.com/photo-1535223289827-42f1e9919769",
  },
  {
    title: "Top Skills Students Must Learn in 2026 for Career Growth",
    date: "January 5, 2026",
    img: "https://images.unsplash.com/photo-1519389950473-47ba0277781c",
  },
]

export default function BlogSection() {
  const trackRef = useRef(null)

  useEffect(() => {
    let offset = 0
    const speed = 0.3

    const animate = () => {
      offset -= speed
      if (trackRef.current) {
        trackRef.current.style.transform = `translateX(${offset}px)`
      }

      if (Math.abs(offset) >= trackRef.current.scrollWidth / 2) {
        offset = 0
      }

      requestAnimationFrame(animate)
    }

    animate()
  }, [])

  return (
    <section className="relative py-24 bg-black overflow-hidden text-white">
      <div className="max-w-7xl mx-auto px-6 mb-12">
        <h2 className="text-3xl font-bold">Latest News</h2>
        <p className="text-gray-400">Education news all over the world.</p>
      </div>

      <div className="relative overflow-hidden">
        <div
          ref={trackRef}
          className="flex items-center gap-10 will-change-transform"
        >
          {[...blogs, ...blogs].map((blog, i) => (
            <div
              key={i}
              className="group relative transition-all duration-500"
              style={{ minWidth: "340px" }}
            >
              <div
                className="
                  bg-black rounded-xl overflow-hidden shadow-xl
                  transform transition-all duration-500
                  group-hover:scale-110
                "
              >
                <img
                  src={blog.img}
                  alt={blog.title}
                  className="w-full h-56 object-cover"
                />

                <div className="p-4">
                  <span className="bg-yellow-400 text-black text-xs px-2 py-1 rounded">
                    Escapenormie · {blog.date}
                  </span>
                  <h3 className="mt-3 text-lg font-semibold leading-snug">
                    {blog.title}
                  </h3>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
